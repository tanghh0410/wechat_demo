package com.test.controller;

import com.test.service.WechatService;
import com.test.service.impl.ContactsUserService;
import com.test.util.QiWeiParametersUtil;
import com.test.util.WeiXinUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 企业微信相关类
 * @Author: tanghh18
 * @Date: 2019/10/8 13:46
 */
@Controller
@Slf4j
public class WechatController {
    @Autowired
    private WechatService wechatService;
    /**
     * 进行扫码登录的操作
     * @param code
     * @return
     */
    @RequestMapping(value = "/getCondition")
    public String getWeixin(@RequestParam("code") String code) {
        try {
            // 得到扫码登陆传过来的code 和state
            // 根据code获取用户信息
            // 1.查询出AccessToken中的值，看是否有应用 AccessToken,无，则调用请求的方法，有则来判断有效时间有没有过期
            String accessToken = WeiXinUtil.getAccessToken(wechatService, "app", QiWeiParametersUtil.corpId, QiWeiParametersUtil.agentSecret);
            ContactsUserService cus = new ContactsUserService();
            cus.getUser2(code, accessToken);
            String name = ContactsUserService.USERNAME;
            System.out.println("当前用户名字----"+name);

            //根据名字查询到当前这条数据
            return "redirect:toIndex";
        } catch (Exception e) {
            log.error("扫描登录失败", e);
        }
        return "wechat.jsp";
    }

    @RequestMapping(value = "/toIndex")
    public String toIndex(){
        return "index.jsp";
    }
}
