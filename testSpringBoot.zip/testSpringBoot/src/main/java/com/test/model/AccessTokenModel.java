package com.test.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * 功能描述: <br>
 * 〈〉
 * @Author: tanghh18
 * @Date: 2019/10/8 13:57
 */
@Entity
@Table(name = "access_token", schema = "test", catalog = "")
public class AccessTokenModel implements Serializable {
    private Integer id;
    private String token;
    private Integer expiresIn;
    private String save_date;
    private String types;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "token")
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Basic
    @Column(name = "expiresIn")
    public Integer getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(Integer expiresIn) {
        this.expiresIn = expiresIn;
    }


    @Basic
    @Column(name = "save_date")
    public String getSave_date() {
        return save_date;
    }

    public void setSave_date(String save_date) {
        this.save_date = save_date;
    }


    @Basic
    @Column(name = "types")
    public String getTypes() {
        return types;
    }

    public void setTypes(String types) {
        this.types = types;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccessTokenModel that = (AccessTokenModel) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(token, that.token) &&
                Objects.equals(expiresIn, that.expiresIn) &&
                Objects.equals(save_date, that.save_date) &&
                Objects.equals(types, that.types);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, token, expiresIn, save_date, types);
    }
}
