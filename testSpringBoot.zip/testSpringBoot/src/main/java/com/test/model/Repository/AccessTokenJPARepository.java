package com.test.model.Repository;

import com.test.model.AccessTokenModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * 功能描述: AccessToken相关类
 * @Author: tanghh18
 * @Date: 2019/10/8 14:01
 */
public interface AccessTokenJPARepository extends JpaRepository<AccessTokenModel, Integer>, JpaSpecificationExecutor<AccessTokenModel> {
    /**
     *     //根据type查询出accessToken中的值
     * @param
     * @return
     */
    @Query("select a from AccessTokenModel a where a.types=?1")
    List<AccessTokenModel> findAccessToken(String type);


}
