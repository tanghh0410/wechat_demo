package com.test.service.impl;

import com.test.model.AccessTokenModel;
import com.test.model.Repository.AccessTokenJPARepository;
import com.test.service.WechatService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.List;

/**
 * 功能描述: 企业微信业务逻辑类
 * @Author: tanghh18
 * @Date: 2019/10/8 14:02
 */
@Service
@Transactional(rollbackFor = Exception.class)
@Slf4j
public class WechatServiceImpl implements WechatService {
    @Autowired
    private AccessTokenJPARepository accessTokenJPARepository;
    /**
     * 1.如果过期的话，则将AccessTokenModel给插入到数据库·中去
     * @param
     * @return
     */

    @Override
    public void saveAccessToken(AccessTokenModel as) {
        try {
            accessTokenJPARepository.save(as);
        } catch (Exception e) {
            log.error("添加access_token失败", e);
        }

    }

    /**
     * 2.查询出AccessTokenModel中的数据
     *
     * @param
     * @return
     */
    @Override
    public List<AccessTokenModel> findAccessToken(String type) {
        try {
            return accessTokenJPARepository.findAccessToken(type);
        } catch (Exception e) {
            log.error("根据token查询accessToken失败", e);
            return null;
        }

    }

    /**
     * 3.根据type去更新AccessTokenModel中的数据
     *
     * @param
     * @return
     */
    @Transactional
    @Override
    public void updateByExpirIn(AccessTokenModel acce) {
        try {
            accessTokenJPARepository.save(acce);
        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("根据id去更新AccessTokenModel中的数据失败", e);
        }

    }
}
