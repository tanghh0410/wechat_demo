package com.test.service;

import com.test.model.AccessTokenModel;

import java.util.List;

/**
 * Created by tanghh on 2019/10/8
 */
public interface WechatService {
    //-------------对AccessTokenModel表进行的操作---------------------------------

    /**
     * 将数据插入到AccessTokenModel中
     * @param as
     */
    void saveAccessToken(AccessTokenModel as);

    /**
     * 2.查询出AccessTokenModel中的值
     * @param type
     * @return
     */
    List<AccessTokenModel> findAccessToken(String type);

    /**
     * 3.根据expirin去修改时间和tokebn
     * @param acce
     */
    void updateByExpirIn(AccessTokenModel acce);
}
