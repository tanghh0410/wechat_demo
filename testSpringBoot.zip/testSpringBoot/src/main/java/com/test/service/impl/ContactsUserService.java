package com.test.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.test.util.QiWeiParametersUtil;
import com.test.wechat.SendRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author thh
 */
public class ContactsUserService {
    private static Logger log = LoggerFactory.getLogger(ContactsUserService.class);

    private String getUserUrl = "https://qyapi.weixin.qq.com/cgi-bin/user/get?access_token=ACCESS_TOKEN&userid=USERID";
    private String deleteUserUrl = "https://qyapi.weixin.qq.com/cgi-bin/user/delete?access_token=ACCESS_TOKEN&userid=USERID";
    private String batchdeleteUserUrl = "https://qyapi.weixin.qq.com/cgi-bin/user/batchdelete?access_token=ACCESS_TOKEN";
    private String getDepartmentUserUrl = "https://qyapi.weixin.qq.com/cgi-bin/user/simplelist?access_token=ACCESS_TOKEN&department_id=DEPARTMENT_ID&fetch_child=FETCH_CHILD";
    private String getUserUrl2 = "https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo?access_token=ACCESS_TOKEN&agentid=AGENTID&code=CODE";

    /**
     * 名字
     */
    public static String USERNAME;
    /**
     * 头像
     */
    public static String AVATARS;


    /**
     * 2.获取成员
     *
     * @param
     * @return
     */
    public void getUser(String userId, String accessToken) {
        //1.获取请求的url
        getUserUrl = getUserUrl.replace("ACCESS_TOKEN", accessToken)
                .replace("USERID", userId);
        //2.调用接口，发送请求，获取成员
        JSONObject jsonObject = SendRequest.sendGet(getUserUrl);
        //得到username将其保存到session中
        String name = jsonObject.get("name").toString();
        ContactsUserService.USERNAME = name;
        String avatar = jsonObject.get("avatar").toString();
        ContactsUserService.AVATARS = avatar;
        //3.错误消息处理
        if (null != jsonObject) {
            if (0 != jsonObject.getIntValue("errcode")) {
                log.error("获取成员失败 errcode:{} errmsg:{}", jsonObject.getIntValue("errcode"), jsonObject.getString("errmsg"));
            }
        }
    }

    /**
     * 2.获取成员
     *
     * @param
     * @return
     */
    public void getUser2(String code, String accessToken) {
        String url = "https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo?access_token=" + accessToken + "&agentid=" + QiWeiParametersUtil.agentId + "&code=" + code;
        //1.获取请求的url
        getUserUrl2 = getUserUrl2.replace("ACCESS_TOKEN", accessToken)
                .replace("CODE", code).replace("AGENTID", QiWeiParametersUtil.agentId + "");
        //2.调用接口，发送请求，获取成员
        JSONObject jsonObject = SendRequest.sendGet(getUserUrl2);

        //3.错误消息处理
        if (null != jsonObject) {
            System.out.println("jsonObject:" + jsonObject.toString());
            getUser(jsonObject.get("UserId").toString(), accessToken);
            //此时这个时候应该把值给传到ResfILTER中
            if (0 != jsonObject.getIntValue("errcode")) {
                log.error("获取成员失败 errcode:{} errmsg:{}", jsonObject.getIntValue("errcode"), jsonObject.getString("errmsg"));
            }
        }
    }

    /**
     * 4.删除成员
     *
     * @param
     * @return
     */
    public void deleteUser(String accessToken, String userId) {

        //1.获取请求的url
        deleteUserUrl = deleteUserUrl.replace("ACCESS_TOKEN", accessToken)
                .replace("USERID", userId);

        //2.调用接口，发送请求，删除成员
        JSONObject jsonObject = SendRequest.sendGet(deleteUserUrl);
        System.out.println("jsonObject:" + jsonObject.toString());

        //3.错误消息处理
        if (null != jsonObject) {
            if (0 != jsonObject.getIntValue("errcode")) {
                log.error("删除成员失败 errcode:{} errmsg:{}", jsonObject.getIntValue("errcode"), jsonObject.getString("errmsg"));
            }
        }
    }

    /**
     * 5.批量删除成员
     *
     * @param
     * @return
     */
    public void batchdeleteUser(String accessToken, List<String> userIdList) {
        //1.获取json字符串：将user对象转换为json字符串
        Map<String, Object> content = new HashMap<String, Object>();
        content.put("useridlist", userIdList);

        String useridlist = JSONObject.toJSONString(content);
        System.out.println(useridlist);

        //2.获取请求的url
        batchdeleteUserUrl = batchdeleteUserUrl.replace("ACCESS_TOKEN", accessToken);

        //3.调用接口，发送请求，创建成员
        JSONObject jsonObject = SendRequest.sendPost(batchdeleteUserUrl, useridlist);
        System.out.println("jsonObject:" + jsonObject.toString());

        //4.错误消息处理
        if (null != jsonObject) {
            if (0 != jsonObject.getIntValue("errcode")) {
                log.error("批量删除成员失败 errcode:{} errmsg:{}", jsonObject.getIntValue("errcode"), jsonObject.getString("errmsg"));
            }
        }
    }


    /**
     * 6.获取部门成员
     *
     * @param
     * @return
     */
    public void getDepartmentUser(String accessToken, String departmentId, String fetchChild) {

        //1.获取请求的url
        getDepartmentUserUrl = getDepartmentUserUrl.replace("ACCESS_TOKEN", accessToken)
                .replace("DEPARTMENT_ID", departmentId)
                .replace("FETCH_CHILD", fetchChild);

        //2.调用接口，发送请求，获取部门成员
        JSONObject jsonObject = SendRequest.sendGet(getDepartmentUserUrl);
        System.out.println("jsonObject:" + jsonObject.toString());

        //3.错误消息处理
        if (null != jsonObject) {
            if (0 != jsonObject.getIntValue("errcode")) {
                log.error("获取部门成员失败 errcode:{} errmsg:{}", jsonObject.getIntValue("errcode"), jsonObject.getString("errmsg"));
            }
        }
    }


    /**
     * 7.获取部门成员详情
     *
     * @param
     * @return
     */
//    public List<BosUserModel> getDepartmentUserDetails(List<String> depts, String accessToken, String fetchChild) {
//        List<BosUserModel> users = new ArrayList<BosUserModel>();
//        for (int j = 0; j < depts.size(); j++) {
//            // 1.获取请求的url
//            String str = getDepartmentUserDetailsUrl
//                    .replace("ACCESS_TOKEN", accessToken)
//                    .replace("DEPARTMENT_ID", depts.get(j))
//                    .replace("FETCH_CHILD", fetchChild);
//
//            // 2.调用接口，发送请求，获取部门成员
//            JSONObject jsonObject = SendRequest.sendGet(str);
//            System.out.println("Contact_service----jsonObject:" + jsonObject.toString());
//
//            // 3.错误消息处理
//            if (null != jsonObject) {
//                if (0 != jsonObject.getIntValue("errcode")) {
//                    log.error("获取部门成员详情失败 errcode:{} errmsg:{}",
//                            jsonObject.getIntValue("errcode"),
//                            jsonObject.getString("errmsg"));
//                } else {//查询成功的话
//                    JSONArray array = jsonObject.getJSONArray("userlist");
//                    System.out.println("userlist----"+array);
//                    if (null != array) {
//                        for (int i = 0; i < array.size(); i++) {
//                            JSONObject de = array.getJSONObject(i);
//                            String userid = de.get("userid").toString();
//                            String department = de.get("department").toString();
//                            String name = de.get("name").toString();
//                            String position = de.get("position").toString();
//                            String mobile = de.get("mobile").toString();
//                            String gender = de.get("gender").toString();
//                            String email = de.get("email").toString();
//                            String avatar = de.get("avatar").toString();
//
//                            //根据名字查询当前这条数据
//                            BosUserModel user = bosUserJPARepositoty.findByName(name);
//                            //这个方法是排除一些用户并非在企业微信里面，而是手动添加的
//                            if(user!=null){
//                                if(!Strings.isNullOrEmpty(userid)){
//                                    user.setUserId(userid);
//                                }
//                                user.setDepartment(splitDepartment);
//                                user.setName(name);
//                                //最后将user放到list中去
//                                users.add(user);
//                            }
//
//
//
//
//
//
//                            //先将名字等信息传过去
////                            BosUserModel user = new BosUserModel();
////                            user.setUserId(userid);
////                            user.setDepartment(department);
////                            user.setName(name);
////                            user.setPosition(position);
////                            user.setMobile(mobile);
////                            user.setGender(gender);
////                            user.setEmail(email);
////                            //头像
////                            user.setAvatar(avatar);
////                            //最后将user放到list中去
////                            users.add(user);
//                        }
//
//                    }
//
//                }
//            }
//        }
//        return users;
//    }
}
