package com.test.util;

import com.alibaba.fastjson.JSONObject;
import com.test.controller.WechatController;
import com.test.model.AccessTokenModel;
import com.test.service.WechatService;
import com.test.wechat.SendRequest;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 功能描述: 微信的工具类
 * @Author: tanghh18
 * @Date: 2019/10/8 13:55
 */
@Slf4j
public class WeiXinUtil {
    /**
     * 获取access_token的接口地址（GET） 限200（次/天）
     * @param
     * @return
     */
    public final static String access_token_url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corpId}&corpsecret={corpsecret}";
    /**
     * 企业微信扫码登录(获取accessToken)
     *
     * @param
     * @return
     */
    public static String getAccessToken(WechatService accService, String type, String corpId, String secret) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            List<AccessTokenModel> access = accService.findAccessToken(type);
            // 如果没有AccessToken的话
            AccessTokenModel accessToken = null;
            if (access.size() <= 0) {
                // 首先要查询到accessToken(第一次查询的话，将accessToken保存到数据库中)
                accessToken = WeiXinUtil.getFirstAccessToken(corpId, secret, type);
                System.out.println("accessToken:" + accessToken.getToken());
                accService.saveAccessToken(accessToken);
                return accessToken.getToken();
            } else {
                accessToken = access.get(0);
                String saveTime = accessToken.getSave_date();
                long time = sdf.parse(saveTime).getTime();
                long now = System.currentTimeMillis();
                long interval = (now - time) / 1000;
                // 超过7000秒，重新获取accessToken
                if (interval > 7000) {
                    accessToken = WeiXinUtil.getFirstAccessToken(QiWeiParametersUtil.corpId, QiWeiParametersUtil.agentSecret, type);
                    // 更新数据库
                    String newDate = sdf.format(new Date());
                    accessToken.setSave_date(newDate);
                    accessToken.setToken(accessToken.getToken());
                    accessToken.setExpiresIn(Integer.parseInt(String
                            .valueOf(interval)));
                    accessToken.setTypes(type);
                    accService.updateByExpirIn(accessToken);
                }
                return accessToken.getToken();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    /**
     * 135 * 3.获取access_token 136 * 137 * @param appid 凭证 138 * @param appsecret
     * 密钥 139 * @return 140
     */
    public static AccessTokenModel getFirstAccessToken(String appid, String appsecret, String type) {
        AccessTokenModel accessToken = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String saveDate = sdf.format(new Date());
        String requestUrl = access_token_url.replace("{corpId}", appid)
                .replace("{corpsecret}", appsecret);
        JSONObject jsonObject = SendRequest.sendPost(requestUrl, "");
        // 如果请求成功
        if (null != jsonObject) {
            try {
                accessToken = new AccessTokenModel();
                accessToken.setToken(jsonObject.getString("access_token"));
                accessToken.setTypes(type);
                accessToken.setSave_date(saveDate);
            } catch (Exception e) {
                accessToken = null;
                // 获取token失败
               log .error("获取token失败 errcode:{} errmsg:{}",
                        jsonObject.getString("errmsg"));
            }
        }
        return accessToken;
    }
}
