package com.test.util;

import com.alibaba.fastjson.JSONObject;
import com.test.wechat.SendRequest;

/**
 * 企业微信参数配置类
 *
 * @Author: tanghh18
 * @Date: 2019/8/30 16:21
 */
public class QiWeiParametersUtil {
    /**
     * 企业ID（yes）+
     */
    public final static String corpId = "企业id";
    /**
     * 企业应用的id，整型。可在应用的设置页面查看(yes)项目测试（ebo0.2版本）
     */
    public final static int agentId = 1000049;
    /**
     * 应用的凭证密钥(yes)  这是ebo0.2版本的
     */
    public final static String agentSecret = "应用秘钥";
    /**
     * 1.获取AccessToken
     */
    public static String getAccessTokenUrl = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corpid}&corpsecret={corpsecret}";

    /**
     * 发送企业微信AccessToken
     */
    public static String sendAccessTokenUrl = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=ACCESS_TOKEN";

    /**
     * 应用secret
     */
    public static String secret = "**********";

    /**
     * 获得各种access_token
     *
     * @return
     */
    public static String getAccessToken() {
        String url = getAccessTokenUrl.replace("{corpid}", corpId).replace("{corpsecret}", secret);
        JSONObject departmentJson = SendRequest.sendGet(url);
        return departmentJson.getString("access_token");
    }
}
